<script type="text/javascript">
  $(document).ready(function(){
    $('.data').DataTable();
  });
</script>


<?php $this->load->view('admin/js'); ?>
</body>

</html>