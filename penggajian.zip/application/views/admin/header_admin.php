<div id='cssmenu'>
  <ul>
      <li><a href='<?php echo site_url('admin/staff/')?>'><span>Staff</span></a></li>
      <li><a href='<?php echo site_url('admin/matakuliah')?>'><span>Mata Kuliah</span></a></li>
      <li><a href='<?php echo site_url('admin/status_staff')?>'><span>Status Staff</span></a></li>
      <li><a href='<?php echo site_url('admin/presensi')?>'><span>Presensi</span></a></li>
      <li><a href='<?php echo site_url('admin/penggajian')?>'><span>Penggajian</span></a></li>
   <li style="float: right"><a href='<?php echo site_url('home/log_out')?>'><span>Logout</span></a></li>
   <li style="float: right"><a href='<?php echo site_url('home/akun')?>'><span>Akun</span></a></li>
</ul>
</div>
