<div id='cssmenu'>
  <ul>
      <li><a href='<?php echo site_url('staff/presensi')?>'><span>Presensi</span></a>
      </li>
      <li><a href='<?php echo site_url('staff/penggajian')?>'><span>Penggajian</span></a>
   </li>
   <li style="float: right"><a href='<?php echo site_url('home/log_out')?>'><span>Logout</span></a></li>
</ul>
</div>
