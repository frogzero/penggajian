<!DOCTYPE html>
<html>

<head>

  <meta charset="UTF-8">

  <title>Grup Penggajian</title>
  
    <script type="text/javascript" src="<?php echo base_url()?>assets/datatable/DataTables/media/js/jquery.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/datatable/DataTables/media/js/jquery.dataTables.js"></script>
    <script src="<?php echo base_url()?>assets/js/jquery-ui.js"></script>
    <script src="<?php echo base_url()?>assets/js/jquery.validate.min.js"></script>


    <link rel="stylesheet" href="<?php echo base_url();?>assets/TambahStaff/tanggal.css">
  
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/datatable/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/datatable/DataTables/media/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/datatable/DataTables/media/css/dataTables.bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/TambahStaff/slimmenu.min.css" type="text/css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/TambahStaff/reg.css" type="text/css">
<!--       <script type="text/javascript" src="<?php echo base_url()?>assets/js/jquery.min.js"></script> -->

</head>

<body>
