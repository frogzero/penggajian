
<center>
	<br>
  <div class="form-title" style="font:50px;">Selamaat Datang di Website Penggajian, Anda dapat menggunakan Menu di Atas</div></center>

<div class="fg-toolbar ui-toolbar ui-widget-header ui-helper-clearfix ui-corner-tl ui-corner-tr" style="margin-top: 40px;">
  